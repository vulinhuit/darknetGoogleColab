
# This project is cloned from [AlexeyAB](https://github.com/AlexeyAB/darknet) with several customization for trainning on google colab 

To practice, you can do as direction at [Bài 26 - Huấn luyện YOLO darknet trên google colab](https://phamdinhkhanh.github.io/2020/03/10/DarknetGoogleColab.html)

Or another simple way opens [darknetGoogleColab.ipynb](https://colab.research.google.com/drive/1G3AM3CHsMb0iwuBDR-j5rimr_WX2KHc2) file and start run from item **3.2. Enable GPU trên google colab**.

After you understand how does darknet work. You could train model on your own data and reserve it for your private task.

# Link to Khanh Blog

Before practice, i recommend you understand YOLO algorithm at [Bài 25 - YOLO You Only Look Once](https://phamdinhkhanh.github.io/2020/03/09/DarknetAlgorithm.html)
